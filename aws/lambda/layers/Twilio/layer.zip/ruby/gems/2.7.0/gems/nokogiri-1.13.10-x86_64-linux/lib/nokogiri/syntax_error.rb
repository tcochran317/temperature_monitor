# frozen_string_literal: true

module Nokogiri
  class SyntaxError < ::StandardError
  end
end
