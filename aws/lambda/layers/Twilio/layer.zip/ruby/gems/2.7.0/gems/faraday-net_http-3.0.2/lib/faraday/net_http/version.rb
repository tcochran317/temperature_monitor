# frozen_string_literal: true

module Faraday
  module NetHttp
    VERSION = '3.0.2'
  end
end
