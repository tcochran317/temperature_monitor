# frozen_string_literal: true

module Faraday
  VERSION = '2.7.2'
end
