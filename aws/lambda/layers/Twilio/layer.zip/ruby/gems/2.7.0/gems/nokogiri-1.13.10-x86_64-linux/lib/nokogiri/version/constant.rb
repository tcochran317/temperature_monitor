# frozen_string_literal: true

module Nokogiri
  # The version of Nokogiri you are using
  VERSION = "1.13.10"
end
